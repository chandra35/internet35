@extends('layouts.admin')

@section('title', 'Edit Pelanggan')

@section('page-title', 'Edit Pelanggan')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="{{ route('admin.customers.index') }}">Pelanggan</a></li>
    <li class="breadcrumb-item"><a href="{{ route('admin.customers.show', $customer) }}">{{ $customer->customer_id }}</a></li>
    <li class="breadcrumb-item active">Edit</li>
@endsection

@push('css')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.css" />
<style>
    .nav-tabs-custom { border-bottom: 2px solid #007bff; }
    .nav-tabs-custom .nav-link { border: none; color: #6c757d; padding: 10px 20px; }
    .nav-tabs-custom .nav-link.active { color: #007bff; border-bottom: 2px solid #007bff; margin-bottom: -2px; background: transparent; }
    #map { height: 300px; border-radius: 8px; }
    .leaflet-control-layers { border-radius: 8px; }
    .leaflet-control-layers-toggle { width: 36px; height: 36px; }
    .photo-upload-box { 
        width: 100%; 
        padding-top: 75%; 
        position: relative;
        border: 2px dashed #dee2e6;
        border-radius: 8px;
        background: #f8f9fa;
        cursor: pointer;
        overflow: hidden;
    }
    .photo-upload-box.has-image { border-style: solid; border-color: #28a745; }
    .photo-upload-box-inner {
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }
    .photo-upload-box img { width: 100%; height: 100%; object-fit: cover; }
    .photo-upload-box .btn-remove {
        position: absolute;
        top: 5px;
        right: 5px;
        z-index: 10;
    }
    #cropperImage { max-width: 100%; }
    #cameraPreview { width: 100%; max-height: 400px; object-fit: cover; border-radius: 8px; }
</style>
@endpush

@section('content')
<form id="customerForm" action="{{ route('admin.customers.update', $customer) }}" method="POST">
    @csrf
    @method('PUT')
    <input type="hidden" name="photo_ktp" id="photo_ktp">
    <input type="hidden" name="photo_selfie" id="photo_selfie">
    <input type="hidden" name="photo_house" id="photo_house">

    <div class="card">
        <div class="card-header p-0 border-bottom-0">
            <ul class="nav nav-tabs nav-tabs-custom" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#tab-info">
                        <i class="fas fa-user mr-1"></i> Informasi
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#tab-address">
                        <i class="fas fa-map-marker-alt mr-1"></i> Alamat
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#tab-service">
                        <i class="fas fa-wifi mr-1"></i> Layanan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#tab-photos">
                        <i class="fas fa-images mr-1"></i> Foto
                    </a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content">
                <!-- Tab Info -->
                <div class="tab-pane fade show active" id="tab-info">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>ID Pelanggan</label>
                                <input type="text" class="form-control" value="{{ $customer->customer_id }}" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Status</label>
                                <input type="text" class="form-control" value="{{ $customer->status_label }}" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nama Lengkap <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" 
                                       value="{{ old('name', $customer->name) }}" required>
                                @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>NIK</label>
                                <div class="input-group">
                                    <input type="text" name="nik" id="nik" class="form-control @error('nik') is-invalid @enderror" 
                                           value="{{ old('nik', $customer->nik) }}" maxlength="16">
                                    @if($hasResidentAccess ?? false)
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-info" id="btnSearchResident" title="Cari Data Penduduk">
                                            <i class="fas fa-search"></i> Cari Penduduk
                                        </button>
                                    </div>
                                    @endif
                                </div>
                                @error('nik')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>No. Telepon <span class="text-danger">*</span></label>
                                <input type="text" name="phone" class="form-control @error('phone') is-invalid @enderror" 
                                       value="{{ old('phone', $customer->phone) }}" required>
                                @error('phone')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>No. Telepon Alternatif</label>
                                <input type="text" name="phone_alt" class="form-control" 
                                       value="{{ old('phone_alt', $customer->phone_alt) }}">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" 
                                       value="{{ old('email', $customer->email) }}">
                                @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Tanggal Lahir</label>
                                <input type="date" name="birth_date" class="form-control" 
                                       value="{{ old('birth_date', $customer->birth_date?->format('Y-m-d')) }}">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <select name="gender" class="form-control select2">
                                    <option value="">-- Pilih --</option>
                                    <option value="male" {{ old('gender', $customer->gender) === 'male' ? 'selected' : '' }}>Laki-laki</option>
                                    <option value="female" {{ old('gender', $customer->gender) === 'female' ? 'selected' : '' }}>Perempuan</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label>Catatan</label>
                                <textarea name="notes" class="form-control" rows="2">{{ old('notes', $customer->notes) }}</textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab Address -->
                <div class="tab-pane fade" id="tab-address">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Provinsi</label>
                                <select name="province_code" id="province_code" class="form-control select2">
                                    <option value="">-- Pilih Provinsi --</option>
                                    @foreach($provinces as $province)
                                    <option value="{{ $province->code }}" {{ old('province_code', $customer->province_code) == $province->code ? 'selected' : '' }}>
                                        {{ $province->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Kabupaten/Kota</label>
                                <select name="city_code" id="city_code" class="form-control select2">
                                    <option value="">-- Pilih Kota --</option>
                                    @foreach($cities as $city)
                                    <option value="{{ $city->code }}" {{ old('city_code', $customer->city_code) == $city->code ? 'selected' : '' }}>
                                        {{ $city->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Kecamatan</label>
                                <select name="district_code" id="district_code" class="form-control select2">
                                    <option value="">-- Pilih Kecamatan --</option>
                                    @foreach($districts as $district)
                                    <option value="{{ $district->code }}" {{ old('district_code', $customer->district_code) == $district->code ? 'selected' : '' }}>
                                        {{ $district->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Kelurahan/Desa</label>
                                <select name="village_code" id="village_code" class="form-control select2">
                                    <option value="">-- Pilih Kelurahan --</option>
                                    @foreach($villages as $village)
                                    <option value="{{ $village->code }}" {{ old('village_code', $customer->village_code) == $village->code ? 'selected' : '' }}>
                                        {{ $village->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="form-group">
                                <label>Alamat Lengkap</label>
                                <textarea name="address" class="form-control @error('address') is-invalid @enderror" 
                                          rows="2">{{ old('address', $customer->address) }}</textarea>
                                @error('address')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Kode Pos</label>
                                <input type="text" name="postal_code" class="form-control" 
                                       value="{{ old('postal_code', $customer->postal_code) }}" maxlength="5">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label>Lokasi di Peta</label>
                                <div id="map"></div>
                                <small class="text-muted">Klik pada peta untuk menandai lokasi</small>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Latitude</label>
                                <input type="text" name="latitude" id="latitude" class="form-control" 
                                       value="{{ old('latitude', $customer->latitude) }}" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Longitude</label>
                                <input type="text" name="longitude" id="longitude" class="form-control" 
                                       value="{{ old('longitude', $customer->longitude) }}" readonly>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab Service -->
                <div class="tab-pane fade" id="tab-service">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Router <span class="text-danger">*</span></label>
                                <select name="router_id" id="router_id" class="form-control select2" required>
                                    <option value="">-- Pilih Router --</option>
                                    @foreach($routers as $router)
                                    <option value="{{ $router->id }}" {{ old('router_id', $customer->router_id) == $router->id ? 'selected' : '' }}>
                                        {{ $router->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Paket Layanan <span class="text-danger">*</span></label>
                                <select name="package_id" id="package_id" class="form-control select2" required>
                                    <option value="">-- Pilih Paket --</option>
                                    @foreach($packages as $package)
                                    <option value="{{ $package->id }}" data-price="{{ $package->price }}"
                                            {{ old('package_id', $customer->package_id) == $package->id ? 'selected' : '' }}>
                                        {{ $package->name }} - Rp {{ number_format($package->price, 0, ',', '.') }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Username PPPoE</label>
                                <div class="input-group">
                                    <input type="text" name="pppoe_username" id="pppoe_username" class="form-control @error('pppoe_username') is-invalid @enderror" 
                                           value="{{ old('pppoe_username', $customer->pppoe_username) }}">
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-outline-primary" id="btnBrowseSecrets" title="Assign dari Mikrotik">
                                            <i class="fas fa-download"></i>
                                        </button>
                                    </div>
                                </div>
                                @error('pppoe_username')
                                <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="text-muted"><i class="fas fa-info-circle mr-1"></i>Klik <i class="fas fa-download"></i> untuk assign PPP Secret dari Mikrotik</small>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Password PPPoE <small class="text-muted">(Kosongkan jika tidak diubah)</small></label>
                                <div class="input-group">
                                    <input type="password" name="pppoe_password" id="pppoe_password" class="form-control">
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-outline-secondary" id="btnTogglePwd">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button type="button" class="btn btn-outline-primary" id="btnGeneratePwd">
                                            <i class="fas fa-sync"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Tipe Layanan</label>
                                <select name="service_type" class="form-control select2">
                                    @foreach(\App\Models\Customer::serviceTypes() as $key => $val)
                                    <option value="{{ $key }}" {{ old('service_type', $customer->service_type) === $key ? 'selected' : '' }}>
                                        {{ $val }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>IP Address (Remote)</label>
                                <input type="text" name="remote_address" class="form-control" 
                                       value="{{ old('remote_address', $customer->remote_address) }}">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>MAC Address</label>
                                <input type="text" name="mac_address" class="form-control" 
                                       value="{{ old('mac_address', $customer->mac_address) }}">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Biaya Bulanan</label>
                                <div class="input-group">
                                    <div class="input-group-prepend"><span class="input-group-text">Rp</span></div>
                                    <input type="number" name="monthly_fee" id="monthly_fee" class="form-control" 
                                           value="{{ old('monthly_fee', $customer->monthly_fee) }}">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Tanggal Jatuh Tempo</label>
                                <select name="billing_day" class="form-control select2">
                                    @for($i = 1; $i <= 28; $i++)
                                    <option value="{{ $i }}" {{ old('billing_day', $customer->billing_day) == $i ? 'selected' : '' }}>
                                        Tanggal {{ $i }}
                                    </option>
                                    @endfor
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Aktif Sampai</label>
                                <input type="date" name="active_until" class="form-control" 
                                       value="{{ old('active_until', $customer->active_until?->format('Y-m-d')) }}">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label>Catatan Internal</label>
                                <textarea name="internal_notes" class="form-control" rows="2">{{ old('internal_notes', $customer->internal_notes) }}</textarea>
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <!-- ODP Selection -->
                    <h6 class="text-muted mb-3"><i class="fas fa-box mr-1"></i> Koneksi ODP (Opsional)</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>ODP</label>
                                <select name="odp_id" id="odp_id" class="form-control select2">
                                    <option value="">-- Tidak Ada / Belum Dipasang --</option>
                                    @foreach($odps as $odp)
                                    <option value="{{ $odp->id }}" 
                                            data-total-ports="{{ $odp->total_ports }}"
                                            data-used-ports="{{ $odp->used_ports }}"
                                            {{ old('odp_id', $customer->odp_id) == $odp->id ? 'selected' : '' }}>
                                        {{ $odp->code }} - {{ $odp->name }} ({{ $odp->total_ports - $odp->used_ports }} port tersedia)
                                    </option>
                                    @endforeach
                                </select>
                                <small class="text-muted">Bisa diisi nanti saat instalasi</small>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Port ODP</label>
                                <select name="odp_port" id="odp_port" class="form-control" {{ $customer->odp_id ? '' : 'disabled' }}>
                                    <option value="">-- Pilih ODP Dulu --</option>
                                </select>
                                <small class="text-muted" id="odp_port_info"></small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab Photos -->
                <div class="tab-pane fade" id="tab-photos">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Foto KTP</label>
                                <div class="photo-upload-box {{ $customer->photo_ktp_url ? 'has-image' : '' }}" data-target="ktp">
                                    <div class="photo-upload-box-inner">
                                        @if($customer->photo_ktp_url)
                                        <img src="{{ $customer->photo_ktp_url }}" id="preview_ktp">
                                        <button type="button" class="btn btn-sm btn-danger btn-remove" onclick="removePhoto('ktp', event)">
                                            <i class="fas fa-times"></i>
                                        </button>
                                        @else
                                        <i class="fas fa-id-card fa-3x text-muted"></i>
                                        <small class="text-muted mt-2">Klik untuk upload</small>
                                        @endif
                                    </div>
                                </div>
                                <input type="file" id="file_ktp" class="d-none" accept="image/*">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Foto Selfie</label>
                                <div class="photo-upload-box {{ $customer->photo_selfie_url ? 'has-image' : '' }}" data-target="selfie">
                                    <div class="photo-upload-box-inner">
                                        @if($customer->photo_selfie_url)
                                        <img src="{{ $customer->photo_selfie_url }}" id="preview_selfie">
                                        <button type="button" class="btn btn-sm btn-danger btn-remove" onclick="removePhoto('selfie', event)">
                                            <i class="fas fa-times"></i>
                                        </button>
                                        @else
                                        <i class="fas fa-user fa-3x text-muted"></i>
                                        <small class="text-muted mt-2">Klik untuk upload</small>
                                        @endif
                                    </div>
                                </div>
                                <input type="file" id="file_selfie" class="d-none" accept="image/*">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Foto Rumah <small class="text-muted">(Opsional)</small></label>
                                <div class="photo-upload-box {{ $customer->photo_house_url ? 'has-image' : '' }}" data-target="house">
                                    <div class="photo-upload-box-inner">
                                        @if($customer->photo_house_url)
                                        <img src="{{ $customer->photo_house_url }}" id="preview_house">
                                        <button type="button" class="btn btn-sm btn-danger btn-remove" onclick="removePhoto('house', event)">
                                            <i class="fas fa-times"></i>
                                        </button>
                                        @else
                                        <i class="fas fa-home fa-3x text-muted"></i>
                                        <small class="text-muted mt-2">Klik untuk upload</small>
                                        @endif
                                    </div>
                                </div>
                                <input type="file" id="file_house" class="d-none" accept="image/*">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="btn-group">
                                <button type="button" class="btn btn-outline-primary" id="btnOpenCamera">
                                    <i class="fas fa-camera mr-1"></i> Ambil Foto dari Kamera
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <div class="row">
                <div class="col">
                    <a href="{{ route('admin.customers.show', $customer) }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left mr-1"></i> Kembali
                    </a>
                </div>
                <div class="col text-right">
                    @if($customer->router_id && $customer->pppoe_username)
                    <button type="button" class="btn btn-{{ $customer->mikrotik_synced ? 'outline-info' : 'info' }} mr-2" id="btnSyncMikrotik">
                        <i class="fas fa-sync mr-1"></i>
                        {{ $customer->mikrotik_synced ? 'Re-sync ke Mikrotik' : 'Sync ke Mikrotik' }}
                    </button>
                    @endif
                    <button type="submit" class="btn btn-primary" id="btnSubmit">
                        <i class="fas fa-save mr-1"></i> Simpan Perubahan
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

<!-- Camera Modal -->
<div class="modal fade" id="cameraModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ambil Foto</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body text-center">
                <video id="cameraPreview" autoplay playsinline></video>
                <canvas id="cameraCanvas" class="d-none"></canvas>
            </div>
            <div class="modal-footer">
                <select id="cameraTarget" class="form-control mr-auto" style="width: auto;">
                    <option value="ktp">Untuk: Foto KTP</option>
                    <option value="selfie">Untuk: Foto Selfie</option>
                    <option value="house">Untuk: Foto Rumah</option>
                </select>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-primary" id="btnCapture">
                    <i class="fas fa-camera mr-1"></i> Ambil
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Cropper Modal -->
<div class="modal fade" id="cropperModal" tabindex="-1" data-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Crop Gambar</h5>
            </div>
            <div class="modal-body">
                <img id="cropperImage" src="">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="btnCropCancel">Batal</button>
                <button type="button" class="btn btn-primary" id="btnCropApply">
                    <i class="fas fa-crop mr-1"></i> Terapkan
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Browse PPP Secrets Modal -->
<div class="modal fade" id="pppSecretsModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-key mr-2"></i>Browse PPP Secret di Mikrotik</h5>
                <button type="button" class="close text-white" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <div class="modal-body p-0">
                <div class="p-3 border-bottom bg-light">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                        </div>
                        <input type="text" class="form-control" id="searchSecrets" placeholder="Cari berdasarkan nama, profile, atau comment...">
                        <div class="input-group-append">
                            <button type="button" class="btn btn-outline-secondary" id="btnRefreshSecrets" title="Refresh">
                                <i class="fas fa-sync-alt"></i>
                            </button>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <small class="text-muted" id="secretsCount">-</small>
                        <div class="btn-group btn-group-sm">
                            <button type="button" class="btn btn-outline-secondary active" data-filter="all">Semua</button>
                            <button type="button" class="btn btn-outline-success" data-filter="active">Aktif</button>
                            <button type="button" class="btn btn-outline-danger" data-filter="disabled">Disabled</button>
                        </div>
                    </div>
                </div>
                <div id="secretsLoading" class="text-center py-5">
                    <i class="fas fa-spinner fa-spin fa-2x text-primary mb-3"></i>
                    <p class="text-muted">Memuat PPP Secrets dari router...</p>
                </div>
                <div id="secretsEmpty" class="text-center py-5 d-none">
                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                    <p class="text-muted">Tidak ada PPP Secret ditemukan</p>
                </div>
                <div id="secretsError" class="text-center py-5 d-none">
                    <i class="fas fa-exclamation-triangle fa-3x text-danger mb-3"></i>
                    <p class="text-danger" id="secretsErrorMsg">Gagal memuat data</p>
                    <button type="button" class="btn btn-sm btn-outline-primary" id="btnRetrySecrets">
                        <i class="fas fa-redo mr-1"></i>Coba Lagi
                    </button>
                </div>
                <div id="secretsTableWrapper" class="d-none">
                    <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                        <table class="table table-hover table-sm mb-0">
                            <thead class="thead-light" style="position: sticky; top: 0; z-index: 1;">
                                <tr>
                                    <th style="width: 30%">Username</th>
                                    <th style="width: 20%">Profile</th>
                                    <th style="width: 30%">Comment</th>
                                    <th style="width: 10%" class="text-center">Status</th>
                                    <th style="width: 10%" class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="secretsTableBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal-footer justify-content-between">
                <small class="text-muted"><i class="fas fa-info-circle mr-1"></i>Pilih secret yang ingin di-assign ke pelanggan ini</small>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

{{-- Resident Search Modal --}}
@if($hasResidentAccess ?? false)
<div class="modal fade" id="residentModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-white"><i class="fas fa-address-book mr-1"></i> Cari Data Penduduk</h5>
                <button type="button" class="close text-white" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <div class="modal-body">
                <div class="input-group mb-3">
                    <input type="text" id="residentSearchInput" class="form-control" placeholder="Ketik NIK, Nama, atau No KK..." autofocus>
                    <div class="input-group-append">
                        <button class="btn btn-info" id="btnResidentSearch"><i class="fas fa-search"></i></button>
                    </div>
                </div>
                <div id="residentSearchResults">
                    <p class="text-muted text-center py-3">Ketik minimal 2 karakter untuk mencari</p>
                </div>
            </div>
            <div class="modal-footer">
                <small class="text-muted"><i class="fas fa-info-circle mr-1"></i>Pilih penduduk untuk mengisi data pelanggan otomatis</small>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
@endif

@endsection

@push('js')
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.js"></script>
<script>
$(function() {
    // Map
    const defaultLat = {{ $customer->latitude ?? -6.2088 }};
    const defaultLng = {{ $customer->longitude ?? 106.8456 }};
    const map = L.map('map').setView([defaultLat, defaultLng], 15);

    // Tile layers
    const googleSat = L.tileLayer('https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
        maxZoom: 20, attribution: '© Google Satellite'
    });
    const googleHybrid = L.tileLayer('https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}', {
        maxZoom: 20, attribution: '© Google Hybrid'
    });
    const googleStreet = L.tileLayer('https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
        maxZoom: 20, attribution: '© Google Maps'
    });
    const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19, attribution: '© OpenStreetMap contributors'
    });
    googleHybrid.addTo(map);

    L.control.layers({
        "🛰️ Satelit + Label": googleHybrid,
        "🛰️ Satelit": googleSat,
        "🗺️ Street": googleStreet,
        "🗺️ OpenStreetMap": osm
    }, null, { position: 'topright' }).addTo(map);
    L.control.scale({ imperial: false }).addTo(map);

    // Customer marker icon
    const customerIcon = L.divIcon({
        className: 'custom-customer-marker',
        html: '<div style="background:#28a745;color:white;padding:5px 10px;border-radius:5px;font-weight:bold;box-shadow:0 2px 5px rgba(0,0,0,0.3);white-space:nowrap;"><i class="fas fa-user"></i> Pelanggan</div>',
        iconSize: [90, 30],
        iconAnchor: [45, 30]
    });

    let marker = null;

    function setMarker(lat, lng) {
        if (marker) {
            marker.setLatLng([lat, lng]);
        } else {
            marker = L.marker([lat, lng], { icon: customerIcon, draggable: true }).addTo(map);
            marker.on('dragend', function(e) {
                const pos = e.target.getLatLng();
                $('#latitude').val(pos.lat.toFixed(8));
                $('#longitude').val(pos.lng.toFixed(8));
            });
        }
        $('#latitude').val(parseFloat(lat).toFixed(8));
        $('#longitude').val(parseFloat(lng).toFixed(8));
    }

    @if($customer->latitude && $customer->longitude)
    setMarker(defaultLat, defaultLng);
    @endif

    map.on('click', function(e) {
        setMarker(e.latlng.lat, e.latlng.lng);
        map.setView(e.latlng, map.getZoom());
    });

    // Geolocation button
    if (navigator.geolocation) {
        const locateBtn = L.control({ position: 'topleft' });
        locateBtn.onAdd = function() {
            const div = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
            div.innerHTML = '<a href="#" title="Lokasi Saya" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;background:white;font-size:16px;"><i class="fas fa-crosshairs"></i></a>';
            div.onclick = function(e) {
                e.preventDefault();
                const btn = div.querySelector('a');
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                navigator.geolocation.getCurrentPosition(function(pos) {
                    map.setView([pos.coords.latitude, pos.coords.longitude], 18);
                    setMarker(pos.coords.latitude, pos.coords.longitude);
                    btn.innerHTML = '<i class="fas fa-crosshairs"></i>';
                    toastr.success('Lokasi ditemukan (akurasi: ' + Math.round(pos.coords.accuracy) + 'm)');
                }, function(err) {
                    btn.innerHTML = '<i class="fas fa-crosshairs"></i>';
                    let msg = 'Tidak dapat mengakses lokasi';
                    if (err.code === 1) msg = 'Izin lokasi ditolak. Aktifkan GPS dan izinkan akses lokasi di browser.';
                    else if (err.code === 2) msg = 'Lokasi tidak tersedia. Pastikan GPS aktif.';
                    else if (err.code === 3) msg = 'Waktu permintaan lokasi habis. Coba lagi.';
                    toastr.error(msg);
                }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
                return false;
            };
            return div;
        };
        locateBtn.addTo(map);
    }

    // Auto-move map when region changes (geocode village/district name)
    function geocodeRegion() {
        // Build query from the most specific selected region
        let query = '';
        const village = $('#village_code option:selected').text().trim();
        const district = $('#district_code option:selected').text().trim();
        const city = $('#city_code option:selected').text().trim();
        const province = $('#province_code option:selected').text().trim();

        if (village && !village.startsWith('--')) query = village + ', ';
        if (district && !district.startsWith('--')) query += district + ', ';
        if (city && !city.startsWith('--')) query += city + ', ';
        if (province && !province.startsWith('--')) query += province;
        query = query.replace(/,\s*$/, '');

        if (!query) return;

        const url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=id&q=' + encodeURIComponent(query);
        $.getJSON(url, function(results) {
            if (results && results.length > 0) {
                const r = results[0];
                map.setView([parseFloat(r.lat), parseFloat(r.lon)], village && !village.startsWith('--') ? 15 : 12);
            }
        });
    }

    $('#village_code').on('change', function() {
        if (!_skipCascade && $(this).val()) geocodeRegion();
    });
    $('#district_code').on('change', function() {
        if (!_skipCascade && $(this).val() && !$('#village_code').val()) geocodeRegion();
    });
    $('#city_code').on('change', function() {
        if (!_skipCascade && $(this).val() && !$('#district_code').val()) geocodeRegion();
    });

    // Fix map display issue when tab is shown
    $('a[href="#tab-address"]').on('shown.bs.tab', function() {
        setTimeout(function() { map.invalidateSize(); }, 100);
    });

    // Region cascade
    let _skipCascade = false;
    const loadRegion = (url, targetId, callback) => {
        $.get(url, function(data) {
            const $target = $(targetId);
            $target.html('<option value="">-- Pilih --</option>');
            data.forEach(item => {
                $target.append(`<option value="${item.code}">${item.name}</option>`);
            });
            if (callback) callback();
        });
    };

    $('#province_code').on('change', function() {
        if (_skipCascade) return;
        const code = $(this).val();
        if (code) {
            loadRegion(`/api/wilayah/cities/${code}`, '#city_code');
            $('#district_code, #village_code').html('<option value="">-- Pilih --</option>');
        }
    });

    $('#city_code').on('change', function() {
        if (_skipCascade) return;
        const code = $(this).val();
        if (code) {
            loadRegion(`/api/wilayah/districts/${code}`, '#district_code');
            $('#village_code').html('<option value="">-- Pilih --</option>');
        }
    });

    $('#district_code').on('change', function() {
        if (_skipCascade) return;
        const code = $(this).val();
        if (code) {
            loadRegion(`/api/wilayah/villages/${code}`, '#village_code');
        }
    });

    // Load packages by router
    $('#router_id').on('change', function() {
        const id = $(this).val();
        if (id) {
            $.get(`/api/routers/${id}/packages`, function(data) {
                const $pkg = $('#package_id');
                $pkg.html('<option value="">-- Pilih Paket --</option>');
                data.forEach(pkg => {
                    $pkg.append(`<option value="${pkg.id}" data-price="${pkg.price}">${pkg.name} - Rp ${Number(pkg.price).toLocaleString('id')}</option>`);
                });
            });
        }
    });

    $('#package_id').on('change', function() {
        const price = $(this).find(':selected').data('price');
        if (price) $('#monthly_fee').val(price);
    });

    // Used ODP ports data from controller
    var usedOdpPorts = @json($usedOdpPorts ?? []);
    var currentCustomerOdpId = "{{ $customer->odp_id ?? '' }}";
    var currentCustomerOdpPort = {{ $customer->odp_port ?? 'null' }};
    
    // ODP change handler - populate port dropdown with protection
    $('#odp_id').on('change', function() {
        const $selected = $(this).find(':selected');
        const odpId = $(this).val();
        const totalPorts = parseInt($selected.data('total-ports')) || 8;
        const $portSelect = $('#odp_port');
        const $portInfo = $('#odp_port_info');
        
        if (!odpId) {
            $portSelect.html('<option value="">-- Pilih ODP Dulu --</option>').prop('disabled', true);
            $portInfo.html('');
            return;
        }
        
        // Get used ports for this ODP
        const usedForOdp = usedOdpPorts[odpId] || {};
        const usedCount = Object.keys(usedForOdp).length;
        const availableCount = totalPorts - usedCount;
        
        // Build options
        let options = '<option value="">-- Pilih Port --</option>';
        for (let i = 1; i <= totalPorts; i++) {
            const usedData = usedForOdp[i];
            // Check if this is the current customer's port (allow re-selection)
            const isCurrentPort = (odpId === currentCustomerOdpId && i === currentCustomerOdpPort);
            
            if (usedData && !isCurrentPort) {
                // Port is used by another customer - disable it
                options += `<option value="${i}" disabled class="text-danger">Port ${i} - ⛔ ${usedData.customer_id}: ${usedData.customer_name}</option>`;
            } else if (isCurrentPort) {
                // This is the current customer's port - select it
                options += `<option value="${i}" selected>Port ${i} - ✅ Port saat ini</option>`;
            } else {
                options += `<option value="${i}">Port ${i} - ✅ Tersedia</option>`;
            }
        }
        $portSelect.html(options).prop('disabled', false);
        
        // Update info text
        if (availableCount > 0) {
            $portInfo.html(`<span class="text-success"><i class="fas fa-info-circle"></i> ${availableCount} dari ${totalPorts} port tersedia</span>`);
        } else {
            $portInfo.html(`<span class="text-danger"><i class="fas fa-exclamation-triangle"></i> Semua port sudah terpakai!</span>`);
        }
    });
    
    // Trigger ODP change on load to populate ports
    @if($customer->odp_id)
    $('#odp_id').trigger('change');
    @endif

    // Password toggle & generate
    $('#btnTogglePwd').on('click', function() {
        const $pwd = $('#pppoe_password');
        const type = $pwd.attr('type') === 'password' ? 'text' : 'password';
        $pwd.attr('type', type);
        $(this).find('i').toggleClass('fa-eye fa-eye-slash');
    });

    $('#btnGeneratePwd').on('click', function() {
        const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let pwd = '';
        for (let i = 0; i < 8; i++) pwd += chars.charAt(Math.floor(Math.random() * chars.length));
        $('#pppoe_password').val(pwd).attr('type', 'text');
    });

    // Photo handling
    let cropper = null;
    let currentTarget = null;
    
    // Track which photos are changed
    const photoChanged = { ktp: false, selfie: false, house: false };

    $('.photo-upload-box').on('click', function() {
        const target = $(this).data('target');
        $(`#file_${target}`).click();
    });

    $('input[type="file"]').on('change', function() {
        const target = $(this).attr('id').replace('file_', '');
        const file = this.files[0];
        if (file) {
            currentTarget = target;
            const reader = new FileReader();
            reader.onload = (e) => {
                $('#cropperImage').attr('src', e.target.result);
                $('#cropperModal').modal('show');
            };
            reader.readAsDataURL(file);
        }
    });

    $('#cropperModal').on('shown.bs.modal', function() {
        cropper = new Cropper(document.getElementById('cropperImage'), {
            aspectRatio: currentTarget === 'ktp' ? 85.6/53.98 : (currentTarget === 'selfie' ? 1 : 4/3),
            viewMode: 1,
        });
    }).on('hidden.bs.modal', function() {
        if (cropper) { cropper.destroy(); cropper = null; }
    });

    $('#btnCropApply').on('click', function() {
        if (cropper) {
            const canvas = cropper.getCroppedCanvas({ maxWidth: 1024, maxHeight: 1024 });
            const base64 = canvas.toDataURL('image/jpeg', 0.8);
            $(`#photo_${currentTarget}`).val(base64);
            
            const $box = $(`.photo-upload-box[data-target="${currentTarget}"]`);
            $box.addClass('has-image');
            $box.find('.photo-upload-box-inner').html(`
                <img src="${base64}" id="preview_${currentTarget}">
                <button type="button" class="btn btn-sm btn-danger btn-remove" onclick="removePhoto('${currentTarget}', event)">
                    <i class="fas fa-times"></i>
                </button>
            `);
            
            photoChanged[currentTarget] = true;
            $('#cropperModal').modal('hide');
        }
    });

    $('#btnCropCancel').on('click', function() {
        $('#cropperModal').modal('hide');
    });

    // Camera
    let stream = null;

    $('#btnOpenCamera').on('click', function() {
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
            .then(s => {
                stream = s;
                document.getElementById('cameraPreview').srcObject = s;
                $('#cameraModal').modal('show');
            })
            .catch(err => {
                toastr.error('Tidak dapat mengakses kamera: ' + err.message);
            });
    });

    $('#cameraModal').on('hidden.bs.modal', function() {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            stream = null;
        }
    });

    $('#btnCapture').on('click', function() {
        const video = document.getElementById('cameraPreview');
        const canvas = document.getElementById('cameraCanvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        canvas.getContext('2d').drawImage(video, 0, 0);
        
        const target = $('#cameraTarget').val();
        currentTarget = target;
        
        $('#cameraModal').modal('hide');
        $('#cropperImage').attr('src', canvas.toDataURL('image/jpeg'));
        $('#cropperModal').modal('show');
    });

    // Form submit
    $('#customerForm').on('submit', function(e) {
        e.preventDefault();
        
        const $btn = $('#btnSubmit');
        $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin mr-1"></i> Menyimpan...');

        $.ajax({
            url: $(this).attr('action'),
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    window.location.href = response.redirect || '{{ route("admin.customers.show", $customer) }}';
                }
            },
            error: function(xhr) {
                const errors = xhr.responseJSON?.errors;
                if (errors) {
                    Object.values(errors).forEach(err => toastr.error(err[0]));
                } else {
                    toastr.error(xhr.responseJSON?.message || 'Terjadi kesalahan');
                }
                $btn.prop('disabled', false).html('<i class="fas fa-save mr-1"></i> Simpan Perubahan');
            }
        });
    });
});

function removePhoto(target, event) {
    event.stopPropagation();
    $(`#photo_${target}`).val('removed');
    const $box = $(`.photo-upload-box[data-target="${target}"]`);
    $box.removeClass('has-image');
    const icons = { ktp: 'fa-id-card', selfie: 'fa-user', house: 'fa-home' };
    $box.find('.photo-upload-box-inner').html(`
        <i class="fas ${icons[target]} fa-3x text-muted"></i>
        <small class="text-muted mt-2">Klik untuk upload</small>
    `);
}

// Browse PPP Secrets
let pppSecretsData = [];

$('#btnBrowseSecrets').on('click', function() {
    const routerId = $('#router_id').val();
    if (!routerId) {
        toastr.warning('Pilih router terlebih dahulu');
        return;
    }
    $('#pppSecretsModal').modal('show');
    loadPPPSecrets(routerId);
});

$('#btnRefreshSecrets, #btnRetrySecrets').on('click', function() {
    const routerId = $('#router_id').val();
    if (routerId) loadPPPSecrets(routerId);
});

$('#searchSecrets').on('input', filterSecretsTable);

$('#pppSecretsModal .btn-group .btn').on('click', function() {
    $(this).siblings().removeClass('active');
    $(this).addClass('active');
    filterSecretsTable();
});

$(document).on('click', '.btn-select-secret', function() {
    const secretId = $(this).data('id');
    const secret = pppSecretsData.find(s => s['.id'] === secretId);
    if (!secret) return;

    $('#pppoe_username').val(secret.name || '');
    $('#pppoe_password').val(secret.password || '');
    $('#pppSecretsModal').modal('hide');

    toastr.success('PPP Secret "' + (secret.name || '') + '" berhasil di-assign.');

    // Highlight fields briefly
    $('#pppoe_username, #pppoe_password').addClass('border-success');
    setTimeout(() => { $('#pppoe_username, #pppoe_password').removeClass('border-success'); }, 2000);

    // Try to match profile with package
    if (secret.profile) {
        $('#package_id option').each(function() {
            if ($(this).text().toLowerCase().includes(secret.profile.toLowerCase())) {
                $('#package_id').val($(this).val()).trigger('change');
                toastr.info('Profile "' + secret.profile + '" cocok dengan paket "' + $(this).text().trim() + '"');
                return false;
            }
        });
    }
});

function loadPPPSecrets(routerId) {
    $('#secretsLoading').removeClass('d-none');
    $('#secretsTableWrapper, #secretsEmpty, #secretsError').addClass('d-none');
    $('#searchSecrets').val('');

    $.ajax({
        url: '{{ url("admin/routers") }}/' + routerId + '/ppp-secrets',
        method: 'GET',
        timeout: 30000,
        success: function(response) {
            $('#secretsLoading').addClass('d-none');
            if (response.success && response.secrets) {
                pppSecretsData = response.secrets;
                if (response.secrets.length === 0) {
                    $('#secretsEmpty').removeClass('d-none');
                    $('#secretsCount').text('0 PPP Secret');
                } else {
                    renderSecretsTable(response.secrets);
                    $('#secretsTableWrapper').removeClass('d-none');
                    $('#secretsCount').text(response.secrets.length + ' PPP Secret ditemukan');
                }
            } else {
                $('#secretsError').removeClass('d-none');
                $('#secretsErrorMsg').text(response.message || 'Gagal memuat PPP Secrets');
            }
        },
        error: function(xhr) {
            $('#secretsLoading').addClass('d-none');
            $('#secretsError').removeClass('d-none');
            $('#secretsErrorMsg').text(xhr.responseJSON?.message || 'Gagal terhubung ke router');
        }
    });
}

function renderSecretsTable(secrets) {
    let html = '';
    secrets.forEach(function(secret) {
        const isDisabled = secret.disabled === 'true';
        const statusBadge = isDisabled
            ? '<span class="badge badge-danger">Disabled</span>'
            : '<span class="badge badge-success">Aktif</span>';
        const rowClass = isDisabled ? 'table-secondary' : '';
        const name = escapeHtml(secret.name || '-');
        const profile = escapeHtml(secret.profile || '-');
        const comment = escapeHtml(secret.comment || '-');

        html += '<tr class="' + rowClass + '" data-name="' + name.toLowerCase() + '" data-profile="' + profile.toLowerCase() + '" data-comment="' + comment.toLowerCase() + '" data-disabled="' + isDisabled + '">' +
            '<td><strong>' + name + '</strong></td>' +
            '<td><span class="badge badge-info">' + profile + '</span></td>' +
            '<td class="text-muted small">' + comment + '</td>' +
            '<td class="text-center">' + statusBadge + '</td>' +
            '<td class="text-center"><button type="button" class="btn btn-sm btn-primary btn-select-secret" data-id="' + secret['.id'] + '" title="Pilih"><i class="fas fa-check"></i></button></td>' +
            '</tr>';
    });
    $('#secretsTableBody').html(html);
}

function filterSecretsTable() {
    const search = $('#searchSecrets').val().toLowerCase();
    const statusFilter = $('#pppSecretsModal .btn-group .btn.active').data('filter') || 'all';
    let visible = 0;
    $('#secretsTableBody tr').each(function() {
        const name = $(this).data('name') || '';
        const profile = $(this).data('profile') || '';
        const comment = $(this).data('comment') || '';
        const isDisabled = $(this).data('disabled');
        const matchesSearch = !search || name.includes(search) || profile.includes(search) || comment.includes(search);
        let matchesStatus = true;
        if (statusFilter === 'active') matchesStatus = !isDisabled;
        if (statusFilter === 'disabled') matchesStatus = isDisabled;
        if (matchesSearch && matchesStatus) { $(this).show(); visible++; } else { $(this).hide(); }
    });
    $('#secretsCount').text(visible + ' dari ' + pppSecretsData.length + ' PPP Secret');
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Sync ke Mikrotik
$('#btnSyncMikrotik').on('click', function(e) {
    e.preventDefault();
    Swal.fire({
        title: 'Sync ke Mikrotik?',
        html: '<p>Sinkronkan PPP Secret <strong>{{ $customer->pppoe_username }}</strong> ke router <strong>{{ $customer->router->name ?? "-" }}</strong>?</p>' +
              '<p class="text-muted small">Pastikan data layanan sudah disimpan sebelum sync.</p>',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: '<i class="fas fa-sync mr-1"></i> Ya, Sync',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#17a2b8',
        showLoaderOnConfirm: true,
        preConfirm: () => {
            return $.ajax({
                url: '{{ route("admin.customers.sync-mikrotik", $customer) }}',
                method: 'POST',
            }).then(response => response).catch(xhr => {
                Swal.showValidationMessage(xhr.responseJSON?.message || 'Gagal sync ke Mikrotik');
            });
        },
        allowOutsideClick: () => !Swal.isLoading()
    }).then((result) => {
        if (result.isConfirmed && result.value) {
            const icon = result.value.already_exists ? 'info' : 'success';
            Swal.fire({
                title: icon === 'success' ? 'Berhasil!' : 'Info',
                text: result.value.message,
                icon: icon,
            }).then(() => location.reload());
        }
    });
});

// ===== Resident Search (Data Kependudukan) =====
@if($hasResidentAccess ?? false)
$('#btnSearchResident').on('click', function() {
    $('#residentSearchInput').val('');
    $('#residentSearchResults').html('<p class="text-muted text-center py-3">Ketik minimal 2 karakter untuk mencari</p>');
    $('#residentModal').modal('show');
    setTimeout(() => $('#residentSearchInput').focus(), 500);
});

function searchResidents() {
    let q = $('#residentSearchInput').val().trim();
    if (q.length < 2) {
        $('#residentSearchResults').html('<p class="text-muted text-center py-3">Ketik minimal 2 karakter untuk mencari</p>');
        return;
    }
    $('#residentSearchResults').html('<p class="text-center py-3"><i class="fas fa-spinner fa-spin"></i> Mencari...</p>');
    $.get('{{ route("admin.residents.search") }}', { q: q }, function(res) {
        if (!res.success || res.data.length === 0) {
            $('#residentSearchResults').html('<p class="text-muted text-center py-3">Tidak ditemukan</p>');
            return;
        }
        let html = '<div class="table-responsive"><table class="table table-sm table-hover"><thead><tr><th>NIK</th><th>Nama</th><th>JK</th><th>TTL</th><th>Alamat</th><th></th></tr></thead><tbody>';
        res.data.forEach(function(r) {
            let ttl = r.tempat_lahir || '';
            if (r.tanggal_lahir) {
                let d = new Date(r.tanggal_lahir);
                ttl += (ttl ? ', ' : '') + d.toLocaleDateString('id-ID');
            }
            let alamat = (r.alamat || '') + (r.dusun ? ' Dsn.' + r.dusun : '') + ' RT' + (r.rt||'') + '/RW' + (r.rw||'');
            html += `<tr>
                <td><code>${r.nik}</code></td>
                <td>${r.nama}</td>
                <td>${r.jenis_kelamin === 'LAKI-LAKI' ? 'L' : 'P'}</td>
                <td>${ttl}</td>
                <td>${alamat}</td>
                <td><button class="btn btn-xs btn-success btn-assign-resident" data-resident='${JSON.stringify(r)}'><i class="fas fa-check"></i> Pilih</button></td>
            </tr>`;
        });
        html += '</tbody></table></div>';
        $('#residentSearchResults').html(html);
    }).fail(function(xhr) {
        $('#residentSearchResults').html('<p class="text-danger text-center py-3">' + (xhr.responseJSON?.message || 'Gagal mencari') + '</p>');
    });
}

$('#btnResidentSearch').on('click', searchResidents);
$('#residentSearchInput').on('keyup', function(e) {
    if (e.key === 'Enter') searchResidents();
});

let residentSearchTimer;
$('#residentSearchInput').on('input', function() {
    clearTimeout(residentSearchTimer);
    residentSearchTimer = setTimeout(searchResidents, 400);
});

$(document).on('click', '.btn-assign-resident', function() {
    let r = $(this).data('resident');

    // Close modal immediately
    $('#residentModal').modal('hide');

    // Fill NIK
    $('input[name="nik"]').val(r.nik);
    // Fill Name
    $('input[name="name"]').val(r.nama);
    // Fill Gender
    let genderVal = r.jenis_kelamin === 'LAKI-LAKI' ? 'male' : 'female';
    $('select[name="gender"]').val(genderVal).trigger('change');
    // Fill Birth Date
    if (r.tanggal_lahir) {
        let d = new Date(r.tanggal_lahir);
        let dateStr = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
        $('input[name="birth_date"]').val(dateStr);
    }
    // Fill Address fields
    if (r.alamat || r.dusun || r.rt || r.rw || r.kelurahan) {
        let fullAddr = (r.alamat || '');
        if (r.dusun) fullAddr += (fullAddr ? ', ' : '') + 'Dusun ' + r.dusun;
        if (r.rt) fullAddr += ' RT ' + r.rt;
        if (r.rw) fullAddr += '/RW ' + r.rw;
        if (r.kelurahan) fullAddr += (fullAddr ? ', ' : '') + r.kelurahan;
        $('textarea[name="address"]').val(fullAddr);
    }

    // Helper: populate select, set value, and force Select2 to re-read
    function fillSelect(selector, data, value, placeholder) {
        let $el = $(selector);
        // Destroy Select2 temporarily
        if ($el.hasClass('select2-hidden-accessible')) {
            $el.select2('destroy');
        }
        $el.empty().append(new Option(placeholder || '-- Pilih --', '', false, false));
        data.forEach(item => {
            $el.append(new Option(item.name, item.code, false, false));
        });
        if (value) {
            $el.val(value);
        }
        // Re-init Select2
        $el.select2({ theme: 'bootstrap-5' });
    }

    // Fill Region codes - cascade in sequence
    if (r.province_code) {
        _skipCascade = true;
        $('#province_code').val(r.province_code).trigger('change');

        $.get(`/api/wilayah/cities/${r.province_code}`, function(cities) {
            fillSelect('#city_code', cities, r.city_code, '-- Pilih Kota --');

            if (r.city_code) {
                $.get(`/api/wilayah/districts/${r.city_code}`, function(districts) {
                    fillSelect('#district_code', districts, r.district_code, '-- Pilih Kecamatan --');

                    if (r.district_code) {
                        $.get(`/api/wilayah/villages/${r.district_code}`, function(villages) {
                            fillSelect('#village_code', villages, r.village_code, '-- Pilih Kelurahan --');
                            _skipCascade = false;
                        });
                    } else { _skipCascade = false; }
                });
            } else { _skipCascade = false; }
        });
    }

    toastr.success('Data penduduk berhasil di-assign ke form pelanggan');
});
@endif
</script>
@endpush
